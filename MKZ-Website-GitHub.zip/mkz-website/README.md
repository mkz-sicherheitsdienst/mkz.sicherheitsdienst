# MKZ Sicherheitsdienst – Website

Responsive, statische Website für MKZ Sicherheitsdienst, Berlin & Brandenburg.

## Website lokal testen
Öffne `index.html` in einem Browser.

## Über GitHub Pages veröffentlichen
1. Melde dich bei GitHub an und erstelle ein neues Repository, z. B. `mkz-sicherheitsdienst`.
2. Lade die Dateien und den Ordner `assets` aus diesem Paket in das Repository hoch. Wichtig: `index.html` muss direkt im Hauptverzeichnis liegen.
3. Öffne im Repository **Settings → Pages**.
4. Wähle bei **Build and deployment** die Option **Deploy from a branch**.
5. Wähle Branch **main** und Ordner **/(root)**, dann **Save**.
6. Nach dem Bereitstellen zeigt GitHub Pages die Website-Adresse in den Pages-Einstellungen an.

## Vor Veröffentlichung unbedingt erledigen
- `impressum.html`: Platzhalter für vollständigen Namen und Geschäftsanschrift ersetzen; nicht mit Platzhaltern veröffentlichen.
- `datenschutz.html`: Angaben zum tatsächlichen Hosting und zur Datenverarbeitung prüfen/ergänzen.
- Das Kontaktformular öffnet derzeit das E-Mail-Programm des Besuchers (mailto). Es verschickt die Nachricht nicht im Hintergrund. Dafür wäre ein Formularanbieter oder ein eigener Server-Endpunkt erforderlich.
- Die Website enthält keine erfundenen Bewertungen, Referenzen oder Zertifizierungsbehauptungen.
