const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Menü schließen' : 'Menü öffnen');
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open'); menuButton.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('contact-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget;
  const name = form.elements.name.value.trim();
  const email = form.elements.email.value.trim();
  const service = form.elements.service.value;
  const message = form.elements.message.value.trim();
  const subject = encodeURIComponent(`Website-Anfrage von ${name} – ${service}`);
  const body = encodeURIComponent(`Guten Tag MKZ Sicherheitsdienst,\n\nmein Name: ${name}\nMeine E-Mail: ${email}\nAnfrage zu: ${service}\n\nNachricht:\n${message}\n\nMit freundlichen Grüßen\n${name}`);
  document.getElementById('form-status').textContent = 'Ihr E-Mail-Programm wird geöffnet. Bitte senden Sie die vorbereitete Nachricht dort ab.';
  window.location.href = `mailto:mkz.sicherheitsdienst@gmail.com?subject=${subject}&body=${body}`;
});
